package com.lokesan.icetask2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var submitButton: Button
    private lateinit var restartButton: Button
    private lateinit var editText: EditText
    private lateinit var textView: TextView
    private var randomNumber: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)
        textView = findViewById(R.id.textView)
        submitButton = findViewById(R.id.submitButton)
        restartButton = findViewById(R.id.restartButton)

        randomNumber = Random.nextInt(1,101)
        val restartButton = findViewById<Button>(R.id.restartButton)
        restartButton.setOnClickListener {
            editText.text.clear()
            textView.text=""
        }

        submitButton.setOnClickListener {
            val userGuess = editText.text.toString().toInt()

            when{
                userGuess == randomNumber ->
                    textView.text ="Correct Guess!"
                userGuess <40 ->
                    //this line states that numbers entered that are lower than 40 will display "Less than"
                    textView.text = "Less Than"
                userGuess in 40..100 ->
                    //numbers entered between 40 - 100 will display "Correct Guess!"
                    textView.text = "Correct Guess!"
                else -> textView.text = "Greater Than"
            //any number value that is entered above 100, will display "greater Than"


            }
        }
    }
}